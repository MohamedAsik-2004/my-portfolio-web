import { Palette, Code, Video, Terminal, Database, Smartphone } from 'lucide-react';
import { motion } from 'framer-motion';

const skillCategories = [
  {
    icon: Palette,
    title: 'UI/UX Design',
    skills: ['Figma', 'Wireframing', 'Prototyping'],
    description: 'Creating intuitive and visually appealing user interfaces',
  },
  {
    icon: Code,
    title: 'Web Development',
    skills: ['WordPress', 'PHP', 'MySQL', 'HTML', 'CSS', 'JavaScript'],
    description: 'Building responsive and dynamic web applications',
  },
  {
    icon: Video,
    title: 'Video Editing',
    skills: ['Adobe Premiere Pro', 'After Effects', 'Motion Graphics'],
    description: 'Producing engaging video content and animations',
  },
  {
    icon: Terminal,
    title: 'Programming',
    skills: ['Java', 'Python', 'C', 'Dart'],
    description: 'Developing efficient and scalable software solutions',
  },
  {
    icon: Smartphone,
    title: 'Mobile Development',
    skills: ['Flutter', 'Android Studio', 'Dart'],
    description: 'Building cross-platform and native mobile applications',
  },
  {
    icon: Database,
    title: 'Database',
    skills: ['SQL'],
    description: 'Managing and optimizing database systems',
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.5,
      ease: [0.25, 0.46, 0.45, 0.94] as const,
    },
  },
};

const Skills = () => {
  return (
    <section id="skills" className="section-padding bg-secondary/50">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="accent-line mx-auto mb-6" />
          <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-4">
            Skills & Expertise
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            A diverse skill set spanning design, development, and creative media
          </p>
        </motion.div>
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-50px' }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {skillCategories.map((category) => (
            <motion.div
              key={category.title}
              variants={itemVariants}
              className="card-elevated card-hover p-8 group"
            >
              <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-6 group-hover:bg-primary/20 transition-colors">
                <category.icon className="w-7 h-7 text-primary" />
              </div>
              <h3 className="font-display text-xl font-semibold text-foreground mb-3">
                {category.title}
              </h3>
              <p className="text-muted-foreground text-sm mb-5">
                {category.description}
              </p>
              <div className="flex flex-wrap gap-2">
                {category.skills.map((skill) => (
                  <span
                    key={skill}
                    className="px-3 py-1.5 bg-secondary text-foreground text-xs font-medium rounded-full"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default Skills;
