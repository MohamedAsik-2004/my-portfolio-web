import { useState } from 'react';
import { Smartphone, Cloud, Leaf, Globe, Palette, Code, Video, ExternalLink, Github } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const projects = [
  {
    id: 1,
    title: 'Evergreen App',
    subtitle: 'Agricultural Weather App',
    category: 'Mobile',
    icon: Leaf,
    description: 'An agricultural weather application that provides real-time weather updates and climate forecasts to assist farmers in selecting suitable crops and vegetables.',
    features: [
      { icon: Cloud, title: 'Smart Farming', desc: 'Intelligent crop planning based on weather data' },
      { icon: Smartphone, title: 'Risk Reduction', desc: 'Reduces weather-related agricultural risks' },
    ],
    tech: ['Java', 'Android SDK', 'Weather API', 'SQLite'],
    gradient: 'from-emerald-500/20 to-teal-500/10',
  },
  {
    id: 2,
    title: 'Portfolio Website',
    subtitle: 'Personal Brand Site',
    category: 'Web',
    icon: Globe,
    description: 'A modern, responsive portfolio website built with React and Tailwind CSS featuring smooth animations and dark mode support.',
    features: [
      { icon: Code, title: 'Modern Stack', desc: 'React, TypeScript, Tailwind CSS' },
      { icon: Palette, title: 'Dark Mode', desc: 'Seamless theme switching' },
    ],
    tech: ['React', 'TypeScript', 'Tailwind CSS', 'Framer Motion'],
    gradient: 'from-blue-500/20 to-indigo-500/10',
  },
  {
    id: 3,
    title: 'E-Commerce Dashboard',
    subtitle: 'Admin Panel Design',
    category: 'Design',
    icon: Palette,
    description: 'A comprehensive UI/UX design for an e-commerce admin dashboard with intuitive navigation and data visualization components.',
    features: [
      { icon: Palette, title: 'Clean UI', desc: 'Intuitive user interface design' },
      { icon: Code, title: 'Component Library', desc: 'Reusable design system' },
    ],
    tech: ['Figma', 'Wireframing', 'Prototyping', 'Design System'],
    gradient: 'from-purple-500/20 to-pink-500/10',
  },
  {
    id: 4,
    title: 'Brand Promo Video',
    subtitle: 'Motion Graphics',
    category: 'Video',
    icon: Video,
    description: 'A dynamic promotional video with motion graphics and visual effects for a tech startup brand launch campaign.',
    features: [
      { icon: Video, title: 'Motion Graphics', desc: 'Custom animations and effects' },
      { icon: Palette, title: 'Brand Identity', desc: 'Consistent visual storytelling' },
    ],
    tech: ['Premiere Pro', 'After Effects', 'Motion Graphics', 'Color Grading'],
    gradient: 'from-orange-500/20 to-red-500/10',
  },
  {
    id: 5,
    title: 'Inventory Manager',
    subtitle: 'Desktop Application',
    category: 'Software',
    icon: Code,
    description: 'A Java-based inventory management system with SQL database integration for small businesses to track products and sales.',
    features: [
      { icon: Code, title: 'Java Application', desc: 'Cross-platform desktop app' },
      { icon: Cloud, title: 'Database', desc: 'SQL-powered data management' },
    ],
    tech: ['Java', 'SQL', 'JavaFX', 'JDBC'],
    gradient: 'from-cyan-500/20 to-blue-500/10',
  },
  {
    id: 7,
    title: 'Raro Food Delivery App',
    subtitle: 'Flutter Mobile App',
    category: 'Mobile',
    icon: Smartphone,
    description: 'A food delivery mobile application built with Flutter and Dart, featuring real-time order tracking, restaurant browsing, and seamless payment integration.',
    features: [
      { icon: Smartphone, title: 'Cross-Platform', desc: 'Flutter-powered iOS & Android app' },
      { icon: Code, title: 'Dart Backend', desc: 'Clean architecture with Dart' },
    ],
    tech: ['Flutter', 'Dart', 'Android Studio', 'Firebase'],
    gradient: 'from-rose-500/20 to-orange-500/10',
  },
  {
    id: 7,
    title: 'Restaurant Website',
    subtitle: 'WordPress Development',
    category: 'Web',
    icon: Globe,
    description: 'A fully responsive restaurant website built on WordPress with online menu, reservation system, and gallery integration.',
    features: [
      { icon: Globe, title: 'Responsive', desc: 'Mobile-first design approach' },
      { icon: Code, title: 'CMS', desc: 'Easy content management' },
    ],
    tech: ['WordPress', 'PHP', 'MySQL', 'CSS'],
    gradient: 'from-amber-500/20 to-yellow-500/10',
  },
];

const categories = ['All', 'Mobile', 'Web', 'Design', 'Video', 'Software'];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 30, scale: 0.95 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      duration: 0.5,
      ease: [0.25, 0.46, 0.45, 0.94] as const,
    },
  },
  exit: {
    opacity: 0,
    scale: 0.95,
    transition: {
      duration: 0.3,
    },
  },
};

const Projects = () => {
  const [activeCategory, setActiveCategory] = useState('All');

  const filteredProjects = activeCategory === 'All'
    ? projects
    : projects.filter(project => project.category === activeCategory);

  return (
    <section id="projects" className="section-padding">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="accent-line mx-auto mb-6" />
          <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-4">
            Featured Projects
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Showcasing work that makes a real-world impact
          </p>
        </motion.div>

        {/* Category Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="flex flex-wrap justify-center gap-3 mb-12"
        >
          {categories.map((category) => (
            <motion.button
              key={category}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setActiveCategory(category)}
              className={`px-5 py-2.5 rounded-full text-sm font-medium transition-all duration-300 ${
                activeCategory === category
                  ? 'bg-primary text-primary-foreground shadow-lg'
                  : 'bg-secondary text-muted-foreground hover:text-foreground hover:bg-secondary/80'
              }`}
            >
              {category}
            </motion.button>
          ))}
        </motion.div>

        {/* Projects Grid */}
        <motion.div
          layout
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-50px' }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          <AnimatePresence mode="popLayout">
            {filteredProjects.map((project) => (
              <motion.div
                key={project.id}
                layout
                variants={itemVariants}
                initial="hidden"
                animate="visible"
                exit="exit"
                className="card-elevated overflow-hidden group"
              >
                {/* Project Header */}
                <div className={`relative p-8 bg-gradient-to-br ${project.gradient} flex items-center justify-center min-h-[180px]`}>
                  <div className="absolute inset-0 overflow-hidden">
                    <div className="absolute -top-10 -right-10 w-32 h-32 bg-primary/10 rounded-full blur-2xl" />
                    <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-primary/5 rounded-full blur-2xl" />
                  </div>
                  <motion.div
                    whileHover={{ scale: 1.1, rotate: 5 }}
                    transition={{ type: 'spring', stiffness: 300 }}
                    className="relative z-10 w-16 h-16 bg-background/80 backdrop-blur-sm rounded-2xl flex items-center justify-center shadow-lg"
                  >
                    <project.icon className="w-8 h-8 text-primary" />
                  </motion.div>
                </div>

                {/* Project Content */}
                <div className="p-6">
                  <div className="flex items-center gap-2 mb-3">
                    <span className="px-2.5 py-1 bg-primary/10 text-primary text-xs font-medium rounded-full">
                      {project.category}
                    </span>
                  </div>
                  
                  <h3 className="font-display text-xl font-bold text-foreground mb-1">
                    {project.title}
                  </h3>
                  <p className="text-muted-foreground text-sm mb-4">
                    {project.subtitle}
                  </p>
                  
                  <p className="text-muted-foreground text-sm leading-relaxed mb-5 line-clamp-3">
                    {project.description}
                  </p>

                  {/* Features */}
                  <div className="space-y-3 mb-5">
                    {project.features.map((feature, idx) => (
                      <div key={idx} className="flex items-start gap-2">
                        <div className="w-6 h-6 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <feature.icon className="w-3 h-3 text-primary" />
                        </div>
                        <div>
                          <span className="text-foreground text-xs font-medium">{feature.title}</span>
                          <p className="text-muted-foreground text-xs">{feature.desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Tech Stack */}
                  <div className="flex flex-wrap gap-1.5">
                    {project.tech.map((tech) => (
                      <span
                        key={tech}
                        className="px-2 py-1 border border-border text-foreground text-xs rounded-md"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      </div>
    </section>
  );
};

export default Projects;
